<?
$width = "600";
$c01 = "C9C9C9";
$c02 = "#EEEEEE";
$co3 = "#DEDEDE";
$title = "<form method=GET action=/index.php><table><tr><th border=30 align=left><input type=number name=topic value=$topic required><input type=hidden name=x value=read><button>თემის არჩევა</button></th></tr>
</table></form>"; 
?>

