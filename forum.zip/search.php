<?php
if (! is_file("head.php")) { } else { include "head.php"; }

error_reporting(0);
$data1 = file("ban/ip.txt");
$data1size = sizeof($data1);
$n = "0";
    do {
    $datatext = explode("|", $data1[$n]);
if ($n == "0") { } else { }
$disallowed = array("$datatext[0]");
$ip = $_SERVER['REMOTE_ADDR']; 

if(in_array($ip, $disallowed)) {
 header("Location: index.php?x=suspended");
 exit;
}
$n++; } while($n < $data1size);
?>
<table align="center" border="1" style="width:100%;height:auto;">
<tr><th align="center"><big>საძიებო</big></th></tr>
<form method=GET><tr><th align="center">რას ვეძებთ</th></tr><tr><td align="center"><input type=text name=keyword required><button>ძებნა</button></form></td></tr></table>
<?php

if (isset($_GET["keyword"])){
   foreach(glob('topics/*.txt') as $file) { 
      $searchfor = $_GET["keyword"];
      $contents = file_get_contents($file);
      $pattern = preg_quote($searchfor, '/');
      $pattern = "/^.*$pattern.*\$/m";
      if(preg_match_all($pattern, $contents, $matches)){
         echo "<table align='center' border='1' style='width:100%;height:auto;'>
<tr><td align='left'>\n";
         echo "\n";
         echo implode("<hr style='color:#efefef'>\n", $matches[0]);
         echo "\n\n</td></tr></table>";
      }
      else{
      }
   }
}
?>
<?php
if (! is_file("bottom.php")) { } else { include "bottom.php"; }
?>
