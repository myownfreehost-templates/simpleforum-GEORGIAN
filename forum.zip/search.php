<?php
if (! is_file("head.php")) { } else { include "head.php"; }
include 'config.php';

echo '<table width=$width cellpadding=0 cellspacing=0 border=0 align=center>';
?>
<center><h2>საძიებო</h2></center>
<form method=GET><table align=center><tr><center>რას ვეძებთ:</center></tr><tr><td><input type=text name=keyword required><tr><th><button>ძებნა</button></th></tr></td></tr></table></form><br>
<?php

if (isset($_GET["keyword"])){
   foreach(glob('topics/*.txt') as $file) { 
      $searchfor = $_GET["keyword"];
      $contents = file_get_contents($file);
      $pattern = preg_quote($searchfor, '/');
      $pattern = "/^.*$pattern.*\$/m";
      if(preg_match_all($pattern, $contents, $matches)){
         echo "<table><tr><td width=$width bgcolor=$c01>\n";
         echo "\n";
         echo implode("<hr style='color:$c01'>\n", $matches[0]);
         echo "\n\n</td></tr></table>";
      }
      else{
      }
   }
}
?>
</td></tr></table><br></table><br>
<?php
if (! is_file("bottom.php")) { } else { include "bottom.php"; }
?>
