<html>
<head>
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0, user-scalable=no">
<Title>ფორუმი</Title>
</head>
<body lang=ka>
<table align="center" border="1" style="width:100%;height:auto;">
<tr><td align="left"><a href='/index.php'>ფორუმი</a></td> <td align="right"><a href='/search.php'>ძებნა</a></td></tr></table>
