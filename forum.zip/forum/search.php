<?php
if (! is_file("head.php")) { } else { include "head.php"; }
include 'config.php';
?>
<center><h2>საძიებო</h2></center>
<form method=GET><table align=center><tr><th>თემის სიტყვის ძებნა</th></tr><tr><td><input type=text name=keyword required><tr><th><button>ძებნა</button></th></tr></td></tr></table></form>
<form method=GET action=/index.php><table align=center><tr><th>თემის ძებნა ნომრით</th></tr><tr><td>
<input type=hidden name=x value=read>
<center><input type=number name=topic size=10 required></center><tr><th><button>მოძებნა</button></th></tr></td></tr></table></form>
<?php

if (isset($_GET["keyword"])){
   foreach(glob('topics/*.txt') as $file) { 
      $searchfor = $_GET["keyword"];
      $contents = file_get_contents($file);
      $pattern = preg_quote($searchfor, '/');
      $pattern = "/^.*$pattern.*\$/m";
      if(preg_match_all($pattern, $contents, $matches)){
         echo "<br><table><tr><td bgcolor=$c01>მოიძებნა:\n";
         echo $file. "\n";
         echo implode("\n", $matches[0]);
         echo "\n\n</td></tr></table><br>";
      }
      else{
      }
   }
}
?>
<br>
<?php
if (! is_file("bottom.php")) { } else { include "bottom.php"; }
?>
