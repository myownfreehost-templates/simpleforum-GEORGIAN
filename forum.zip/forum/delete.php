<?php
if (! is_file("head.php")) { } else { include "head.php"; }
?>
<?

$topic = $_POST['topic'];
@unlink("topics/$topic.txt");

?>
<center><h2>თემის წაშლა</h2></center>
<form method=POST><table align=center><tr><center>თემის ნომერი:</center></tr><tr><td><center><input type=number name=topic size=10 required></center><tr><th><button>წაშლა</button></th></tr></td></tr></table></form><br><br>
<?php
if (! is_file("bottom.php")) { } else { include "bottom.php"; }
?>
