<?php
if (! is_file("head.php")) { } else { include "head.php"; }
?>
<?

$topic = $_POST['topic'];
@unlink("files/$topic.txt");

?>
<form method=POST><table align=center><tr><th>თემის id</th></tr><tr><td><input type=number name=topic required><tr><th><button>წაშლა</button></th></tr></td></tr></table></form><br>
<?php
if (! is_file("bottom.php")) { } else { include "bottom.php"; }
?>
