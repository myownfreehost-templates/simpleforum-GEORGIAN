<html>
<head>
<title>თემის წაშლა</title>
</head>
<body>
<?
$topic = $_POST['topic'];
@unlink("files/$topic.txt");
@file("files/topics.txt");
unset($topic);  
print "<form method='POST' action=''><center>თემის id: <input type='text' name='topic'><button>წაშლა</button><center></form>";
?>
</body>
</html>
