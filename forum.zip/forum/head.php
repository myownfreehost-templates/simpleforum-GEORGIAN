<head>
<Title>ფორუმი</Title>
</head>
<body lang=KA style='tab-interval:35.4pt'>
<table align=center width=600>
<tr>
<th>
<table class=MsoNormalTable border=0 align=center cellspacing=0 cellpadding=0 bgcolor="#9db0cb"
 style='margin-left:29.55pt;border-collapse:collapse;border:none;mso-border-alt:
 three-d-engrave windowtext 6.0pt;mso-padding-alt:0cm 5.4pt 0cm 5.4pt;
 mso-border-insideh:6.0pt three-d-engrave windowtext;mso-border-insidev:6.0pt three-d-engrave windowtext'>
 <tr style='mso-yfti-irow:0;mso-yfti-lastrow:yes;height:351.0pt'>
  <td width=400 valign=top style='width:441.0pt;border:double windowtext 6.0pt;
  mso-border-alt:three-d-engrave windowtext 6.0pt;padding:0cm 5.4pt 0cm 5.4pt;
  height:250.0pt'> <p class=MsoNormal><o:p>&nbsp;</o:p>


<body bgcolor="#a0c0c0">
<table border=0 align=center>
<tr><td>
<table width="500" align="center" cellspacing="1" cellpadding="1" bgcolor="#9db0cb">
  <TBODY>
  <TR>
    <TD vAlign=bottom align=middle bgColor=#ffffff colSpan=2>
    <IMG height=56 
      src="img/fr_head.png" width=600 border=0></TD></TR>
  <TR>
    <TD align=middle bgColor=#9db0cb colSpan=2><center><a href='/index.php'>მთავარი გვერდი</a></center></TD></TR>
  <TR>
    <TD bgColor=#ffffff colSpan=2>
      <P align=center><IMG height=16 src="img/gb_div1.gif" 
      width=600 border=0></P></TD></TR>
  <TR>
    <TD colSpan=2 height=5>&nbsp;</TD></TR>
  <TR>
    <TD bgColor=#9db0cb colSpan=2>
      <DIV align=center>
      <TABLE cellSpacing=0 cellPadding=0 width=524 border=0>
        <TBODY>
