<?
$width = "600";
$c01 = "C9C9C9";
$c02 = "#EEEEEE";
$co3 = "#DEDEDE";
$title = "<font color='ffffff' size=4><b><center>ფორუმი</center></b></font>"; 
?>

