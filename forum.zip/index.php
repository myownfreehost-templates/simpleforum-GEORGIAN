<?
if (! is_file("head.php")) { } else { include "head.php"; }

session_start();
date_default_timezone_set("Asia/Tbilisi"); 

$path='online/';
$file_name='sess_'.$_COOKIE['PHPSESSID'];
$file=$path.$file_name;
$atime=300;

function inc_count($path,$file,$atime)
{
    !is_dir($path)?mkdir($path,0755,true):false;
    !file_exists($file)?fopen($file, "w"):false;
    $time=file_get_contents($file);
    empty($time)?file_put_contents($file, (time()+$atime)):false;
    if($time<=time())
    {
    file_put_contents($file, time()+$atime);
    }
    if ($handle = opendir($path))
    {
	while (false !== ($entry = readdir($handle)))
	{
	    if ($entry != "." && $entry != "..")
	    {
		$time=file_get_contents($path.$entry);
		if($time<=time())
		{
		unlink($path.$entry);
		}
	    }
	}
	closedir($handle);
	$prefix = ((count(scandir($path))-2) == 1) ? 'მხოლოდ თქვენ' : 'თქვენი ჩათვლით';
	return '<table align="center" border="1" style="width:100%;height:auto;"><tr><td align="left">საიტზეა <span id="blink"><blink><font color=green><b>'.(count(scandir($path))-2).'</b></font></blink></span> ადამიანი <font style="color:gray;"><small>' . $prefix . '. ბოლო '.($atime / 60).' წუთში</font></small></td></tr></table>';
    }
}

echo inc_count($path,$file,$atime);

error_reporting(0);
$x = $_GET["x"];
$part = $_GET["part"];
$topic = $_GET["topic"];
$name = $_POST["name"];
$subject = $_POST["subject"];
$email = $_POST["email"];
$text = $_POST["text"];
$ip = $_POST["ip"];

$ip = isset($_SERVER['HTTP_CLIENT_IP']) 
    ? $_SERVER['HTTP_CLIENT_IP'] 
    : isset($_SERVER['HTTP_X_FORWARDED_FOR']) 
      ? $_SERVER['HTTP_X_FORWARDED_FOR'] 
      : $_SERVER['REMOTE_ADDR'];

print "<table align='center' border='1' style='width:100%;height:auto;'><tr><td align='left'> <a href='index.php?x=add'>ახალი თემის გახსნა</a></td></tr></table><table align='center' border='1' style='width:100%;height:auto;'><form method=GET action=/index.php><tr><td align='right'><input type=number size=10 name=topic value=$topic required><input type=hidden name=x value=read><button>თემის არჩევა</button></form></td></tr></table>";

switch($x) :
default :
$data1 = file("ban/ip.txt");
$data1size = sizeof($data1);
$n = "0";
    do {
    $datatext = explode("|", $data1[$n]);
if ($n == "0") { } else { }
$disallowed = array("$datatext[0]");
$ip = $_SERVER['REMOTE_ADDR']; 

if(in_array($ip, $disallowed)) {
 header("Location: index.php?x=suspended");
 exit;
}
$n++; } while($n < $data1size);


$data1 = file("topics.txt");
$data1size = sizeof($data1);

if ($part == "") {
$n = "$data1size";
                 } else {
                         $part2 = $part*10;
                         $n = $data1size-$part2;
                        }
$g = "0";
$limx=0;
    do {
    $limx++;
      $n2 = $n+1;

    $textdata = explode("|", $data1[$n]);
    $textfile = "topics/$n2.txt";
      if (! is_file("$textfile")) { } else {
      $xx = "0";
      $data2 = file("$textfile");
      $data2size = sizeof($data2);
      if ($data2size < 2) { $color = "red"; } else { $color = "blue"; }
  $textdata[3] = substr($textdata[3],0,200);
  $textdata[1] = substr($textdata[1],0,50);



      do {
      $textdata2 = explode("|", $data2[$xx]);
      if ($textdata2[1] != "") {

  $textdata2[3] = substr($textdata2[3],0,200);
  $textdata2[1] = substr($textdata2[1],0,50);
    if ($textdata[1] != "") {
    print '<table align="center" border="1" style="width:100%;height:auto;">';
  print "<tr><td align='left'> <a style='border: 1px solid $color; color: $color;' href='index.php?x=read&topic=$n2'>$textdata2[3]</a></td> <td align='right'><b>"; if ($textdata2[4] != "") { print '<a href="mailto:$textdata2[4]">'; } print "$textdata2[1]</a></b> <font style='display: inline-block; box-shadow: 1px 1px 1px 1px #ffffff; background-color: #e1f1e1; border-radius: 5px 5px 5px 5px; color: black; border: 2px solid #ffffff; padding: 1px 1px;'>$textdata2[2]</font></td></tr></table>\r\n";
                          } 

                               }
      
      if ($xx > $limit) { $xx = "$data2size"; }
      if ($limx > 10) { $n = "0"; }
      } while($xx < $data2size);
      } 

    $n--;
    } while($n+1 > 0);
 
print "<table align='center' border='1' style='width:100%;height:auto;'><tr><td align='right'>თემები: $data1size</td></tr></table>";
print '<table align="center" border="1" style="width:100%;height:auto;"><tr><td align="left">';





$num4 = $data1size/10;
$num4 = explode(".", $num4);
$n = "0";

do {
$nn = $n+1;
print " <a href='index.php?part=$n&x=$x&topic=$topic'>$nn</a> ";
$n++;
 } while($n < $num4[0]+1);

 print "</td><tr></table>";
break;
case("read") :

$data1 = file("ban/ip.txt");
$data1size = sizeof($data1);
$n = "0";
    do {
    $datatext = explode("|", $data1[$n]);
if ($n == "0") { } else { }
$disallowed = array("$datatext[0]");
$ip = $_SERVER['REMOTE_ADDR']; 

if(in_array($ip, $disallowed)) {
 header("Location: index.php?x=suspended");
 exit;
}
$n++; } while($n < $data1size);

print "<script type='text/javascript'>

function paste_string(e, s){
e.value+=s;
e.focus();

}
function get_sel()
{

  if (window.getSelection) return window.getSelection(); else if
     (document.getSelection) return document.getSelection(); else if
     (document.selection) return document.selection.createRange().text; else return;

}
function quote_sel(e)
{

  sel = get_sel();
  paste_string(e, ' [quote]'+sel+'[/quote] ');
}

</script>
<script type='text/javascript'>
   function addTextTag(text){

    document.getElementById(`text`).value += text;
   }        
</script>";
if ($topic == "") { print "<table align='center' border='1' style='width:100%;height:auto;'><tr><th align='center'><big>შეცდომა!</big> - შეავსეთ თემის არჩევის ID!</th></tr></table>"; if (! is_file("bottom.php")) { } else { include "bottom.php"; } exit; }
  function showBBcodes($text) {
	$text  = htmlspecialchars($text, ENT_QUOTES, $charset);
	$find = array(
	    '~\[youtube\](.*?)\[/youtube\]~s',
		'~\[b\](.*?)\[/b\]~s',
		'~\[i\](.*?)\[/i\]~s',
		'~\[u\](.*?)\[/u\]~s',
		'~\[s\](.*?)\[/s\]~s',
		'~\[spoiler\](.*?)\[/spoiler\]~s',
		'~\[quote\](.*?)\[/quote\]~s',
		'~\[size=(.*?)\](.*?)\[/size\]~s',
		'~\[color=(.*?)\](.*?)\[/color\]~s',
		'~\[url\]((?:ftp|https?)://.*?)\[/url\]~s',
		'~\[link=([^"><]*?)\](.*?)\[/link\]~s',
		'~\[img\](https?://.*?\.(?:jpg|jpeg|gif|png|bmp))\[/img\]~s',
		'~\[left\](.*?)\[/left\]~s',
		'~\[right\](.*?)\[/right\]~s',
		'~\[center\](.*?)\[/center\]~s',
		'~\[br\]~s',
		'<br>',
		'~\[hr\]~s'
	);
	$replace = array(
	    '<fieldset><legend><small><font color="gray"><b>YouTube ვიდეო</b></font></small></legend><iframe height="100%" width="100%" src="https://www.youtube.com/embed/$1"></iframe></fieldset>',
		'<b>$1</b>',
		'<i>$1</i>',
		'<span style="text-decoration:underline;">$1</span>',
		'<s>$1</s>',
		'<fieldset><legend><small><font color="gray"><b>სპოილერი</b></font></small></legend><details><summary><font style="width:100%; background-color:#efefef; color:#0000ff; border:1px solid; border-color:#999999;">სპოილერის სანახავად დააწკაპეთ აქ</font></summary><hr style="color:#efefef">$1</details></fieldset>',
		'<fieldset><legend><small><font color="gray"><b>ციტატა</b></font></small></legend><div style="width:100%; background-color:#efefef; color:#333333; border:1px solid; border-color:#efefef;">$1</div></fieldset>',
		'<span style="font-size:$1px;">$2</span>',
		'<span style="color:$1;">$2</span>',
		'<a href="$1">$1</a>',
		'<a href="$1">$2</a>',
		'<fieldset><legend><small><font color="gray"><b>ფოტო სურათი</b></font></small></legend><img src="$1" style="width:100%; alt="" /></fieldset>',
		'<div style="text-align: left;">$1</div>',
		'<div style="text-align: right;">$1</div>',
		'<center>$1</center>',
		'<br>',
		'...',
		'<hr style="width:100%; color:#dddddd;">'
	);
	return preg_replace($find,$replace,$text);
}
$data1 = file("topics/$topic.txt");
$data1size = sizeof($data1);
   
if ($part == "") {
$n = "$data1size";
                 } else {
                         $part2 = $part*10;
                         $n = $data1size-$part2;
                        }

$limx=0;
    do {
    $limx++;

    $datatext = explode("|", $data1[$n]);
if ($n == "0") { $col = $c01; $subject = ""; } else { $col = $c01; }
$bbtext = $datatext[3];
$datatext[3] = showBBcodes($bbtext);
if ($datatext[3] != "") {
print "<table align='center' border='1' style='width:100%;height:auto;'><tr><td align='left'>
<font size=2># <font color='gray'>$datatext[0]</font></td><td align='right'>";  if ($datatext[4] != "") { print "<a href='mailto:$datatext[4]'>"; } print "<b>$datatext[1]</b></a><font style='display: inline-block; box-shadow: 1px 1px 1px 1px #ffffff; background-color: #e1f1e1; border-radius: 5px 5px 5px 5px; color: black; border: 2px solid #ffffff; padding: 1px 1px;'> $datatext[2]</font></td></tr></table>
<table align='center' border='1' style='width:100%;height:auto;'><tr><td align='left'>$datatext[3]
</td></tr></table><table align='center' border='1' style='width:100%;height:auto;'><tr><td align='left'><small><font color=blue>IP</font> <font color=green>მისამართი:</font> <font color=red>$datatext[5]</font></small></td><td align='center'><a href='javascript:void(0)' title='მომხმარებლის სახელის ჩასმა გამოხმაურებაში' onClick='addTextTag(` [b]$datatext[1][/b], `); return false'>პასუხი</a></td><td align='center'><a href='javascript:void(0)' title='მონიშნეთ ტექსტი და დააწკაპეთ ამ ღილაკს რათა ჩასვათ ციტატა გამოხმაურებაში' onmousedown='javascript:quote_sel(document.PForm.text); return false;'>ციტატა</a></td></tr></table>";
      } 
      $n--;
      if ($limx > 10) { $n = "0"; }
      } while($n);
print '<table align="center" border="1" style="width:100%;height:auto;"><tr><td align="left">';





$num4 = $data1size/10;
$num4 = explode(".", $num4);
$n = "0";

do {
$nn = $n+1;
print " <a href='index.php?part=$n&x=$x&topic=$topic'>$nn</a> ";
$n++;
 } while($n < $num4[0]+1);

 print "</td><tr></table>";     
print "<table align='center' border='1' style='width:100%;height:auto;'><tr><th align='center'><big>პასუხის გამოქვეყნება</big></th></tr></table>
<form name=PForm action=index.php?x=add2reply&topic=$topic method=post><table align='center' border='1' style='width:100%;height:auto;'><tr>
<input type=hidden name=subject value=\"\"><tr><th align='center'>სახელი <font color=red>*</font></th><th align='center'>ელ. ფოსტა</th></tr><td align='center'><input type=text name=name value='".$_COOKIE["name"]."' maxlength=20 style=\"width: 100%;\"></td><td align='center'><input type=text name=email value='".$_COOKIE["email"]."' style=\"width: 100%;\"></td></tr>
<table align='center' border='1' style='width:100%;height:auto;'><tr><td align='center'>
<center><fieldset><legend><small><font color='gray'>BB კოდები</font></small></legend>
<small><a href='javascript:void(0)' onClick='addTextTag(` [b] მსხვილი ტექსტი [/b] `); return false'>B</a> <a href='javascript:void(0)' onClick='addTextTag(` [i] დახრილი ტექსტი [/i] `); return false'>I</a> <a href='javascript:void(0)' onClick='addTextTag(` [u] ხაზგასმული ტექსტი [/u] `); return false'>U</a> <a href='javascript:void(0)' onClick='addTextTag(` [s] გადახაზული ტექსტი [/s] `); return false'>S</a> <a href='javascript:void(0)' onClick='addTextTag(` [spoiler] ტექსტი [/spoiler] `); return false'>SPOILER</a> <a href='javascript:void(0)' onClick='addTextTag(` [quote] ციტატა [/quote] `); return false'>QUOTE</a> <a href='javascript:void(0)' onClick='addTextTag(` [size=30] ტექსტი [/size] `); return false'>SIZE</a> <a href='javascript:void(0)' onClick='addTextTag(` [color=green] ტექსტი [/color] `); return false'>COLOR</a> <a href='javascript:void(0)' onClick='addTextTag(` [url] ბმული [/url] `); return false'>URL</a> <a href='javascript:void(0)' onClick='addTextTag(` [link= ბმული ] სახელი [/link] `); return false'>LINK</a> <a href='javascript:void(0)' onClick='addTextTag(` [img] ფოტო სურათის ბმული [/img] `); return false'>IMG</a> <a href='javascript:void(0)' onClick='addTextTag(` [youtube] ვიდეოს კოდი ბმულიდან [/youtube] `); return false'>YOUTUBE</a>
 <a href='javascript:void(0)' onClick='addTextTag(` [left] ტექსტი მარჯვნივ [/left] `); return false'>LEFT</a>
  <a href='javascript:void(0)' onClick='addTextTag(` [right] ტექსტი მარცხნივ [/right] `); return false'>RIGHT</a>
 <a href='javascript:void(0)' onClick='addTextTag(` [center] ტექსტი ცენტრში [/center] `); return false'>CENTER</a>
  <a href='javascript:void(0)' onClick='addTextTag(` [br] ტექსტი ახალი ხაზიდან `); return false'>BREAK</a>
   <a href='javascript:void(0)' onClick='addTextTag(` [hr] ხაზის გასმა `); return false'>LINE</a></small>
</center></fieldset></th></tr></table>
<table align='center' border='1' style='width:100%;height:auto;'><tr><th align='center'>გამოხმაურება <font color=red>*</font></th></tr><tr><td align='center'><textarea rows=7 name=text id=text style=\"width: 100%;\"></textarea><br><input type=submit value=\"გამოქვეყნება\" style=\"width: 100%;\"></td></tr>
</td></tr></table>
<table align='center' border='1' style='width:100%;height:auto;'><tr><td align='center'><fieldset><legend><small><font color='gray'>სიცილაკები</font></small></legend>
<a href='javascript:void(0)' onClick='addTextTag(`&#128512;`); return false'>&#128512;</a>
<a href='javascript:void(0)' onClick='addTextTag(`&#128514;`); return false'>&#128514;</a>
<a href='javascript:void(0)' onClick='addTextTag(`&#128515;`); return false'>&#128515;</a>
<a href='javascript:void(0)' onClick='addTextTag(`&#128516;`); return false'>&#128516;</a>
<a href='javascript:void(0)' onClick='addTextTag(`&#128517;`); return false'>&#128517;</a>
<a href='javascript:void(0)' onClick='addTextTag(`&#128518;`); return false'>&#128518;</a>
<a href='javascript:void(0)' onClick='addTextTag(`&#128519;`); return false'>&#128519;</a>
<a href='javascript:void(0)' onClick='addTextTag(`&#128520;`); return false'>&#128520;</a>
<a href='javascript:void(0)' onClick='addTextTag(`&#128521;`); return false'>&#128521;</a>
<a href='javascript:void(0)' onClick='addTextTag(`&#128522;`); return false'>&#128522;</a>
<a href='javascript:void(0)' onClick='addTextTag(`&#128523;`); return false'>&#128523;</a>
<a href='javascript:void(0)' onClick='addTextTag(`&#128524;`); return false'>&#128524;</a>
<a href='javascript:void(0)' onClick='addTextTag(`&#128525;`); return false'>&#128525;</a>
<a href='javascript:void(0)' onClick='addTextTag(`&#128526;`); return false'>&#128526;</a>
<a href='javascript:void(0)' onClick='addTextTag(`&#128527;`); return false'>&#128527;</a>
<a href='javascript:void(0)' onClick='addTextTag(`&#128528;`); return false'>&#128528;</a>
<a href='javascript:void(0)' onClick='addTextTag(`&#128529;`); return false'>&#128529;</a>
<a href='javascript:void(0)' onClick='addTextTag(`&#128530;`); return false'>&#128530;</a>
<a href='javascript:void(0)' onClick='addTextTag(`&#128531;`); return false'>&#128531;</a>
<a href='javascript:void(0)' onClick='addTextTag(`&#128532;`); return false'>&#128532;</a>
<a href='javascript:void(0)' onClick='addTextTag(`&#128533;`); return false'>&#128533;</a>
<a href='javascript:void(0)' onClick='addTextTag(`&#128534;`); return false'>&#128534;</a>
<a href='javascript:void(0)' onClick='addTextTag(`&#128535;`); return false'>&#128535;</a>
<a href='javascript:void(0)' onClick='addTextTag(`&#128536;`); return false'>&#128536;</a>
<a href='javascript:void(0)' onClick='addTextTag(`&#128537;`); return false'>&#128537;</a>
<a href='javascript:void(0)' onClick='addTextTag(`&#128538;`); return false'>&#128538;</a>
<a href='javascript:void(0)' onClick='addTextTag(`&#128539;`); return false'>&#128539;</a>
<a href='javascript:void(0)' onClick='addTextTag(`&#128540;`); return false'>&#128540;</a>
<a href='javascript:void(0)' onClick='addTextTag(`&#128541;`); return false'>&#128541;</a>
<a href='javascript:void(0)' onClick='addTextTag(`&#128542;`); return false'>&#128542;</a>
<a href='javascript:void(0)' onClick='addTextTag(`&#128543;`); return false'>&#128543;</a>
<a href='javascript:void(0)' onClick='addTextTag(`&#128544;`); return false'>&#128544;</a>
<a href='javascript:void(0)' onClick='addTextTag(`&#128545;`); return false'>&#128545;</a>
<a href='javascript:void(0)' onClick='addTextTag(`&#128546;`); return false'>&#128546;</a>
<a href='javascript:void(0)' onClick='addTextTag(`&#128547;`); return false'>&#128547;</a>
<a href='javascript:void(0)' onClick='addTextTag(`&#128548;`); return false'>&#128548;</a>
<a href='javascript:void(0)' onClick='addTextTag(`&#128549;`); return false'>&#128549;</a>
<a href='javascript:void(0)' onClick='addTextTag(`&#128550;`); return false'>&#128550;</a>
<a href='javascript:void(0)' onClick='addTextTag(`&#128551;`); return false'>&#128551;</a>
<a href='javascript:void(0)' onClick='addTextTag(`&#128552;`); return false'>&#128552;</a>
<a href='javascript:void(0)' onClick='addTextTag(`&#128553;`); return false'>&#128553;</a>
<a href='javascript:void(0)' onClick='addTextTag(`&#128554;`); return false'>&#128554;</a>
<a href='javascript:void(0)' onClick='addTextTag(`&#128555;`); return false'>&#128555;</a>
<a href='javascript:void(0)' onClick='addTextTag(`&#128556;`); return false'>&#128556;</a>
<a href='javascript:void(0)' onClick='addTextTag(`&#128557;`); return false'>&#128557;</a>
<a href='javascript:void(0)' onClick='addTextTag(`&#128558;`); return false'>&#128558;</a>
<a href='javascript:void(0)' onClick='addTextTag(`&#128559;`); return false'>&#128559;</a>
<a href='javascript:void(0)' onClick='addTextTag(`&#128560;`); return false'>&#128560;</a>
<a href='javascript:void(0)' onClick='addTextTag(`&#128561;`); return false'>&#128561;</a>
<a href='javascript:void(0)' onClick='addTextTag(`&#128562;`); return false'>&#128562;</a>
<a href='javascript:void(0)' onClick='addTextTag(`&#128563;`); return false'>&#128563;</a>
<a href='javascript:void(0)' onClick='addTextTag(`&#128564;`); return false'>&#128564;</a>
<a href='javascript:void(0)' onClick='addTextTag(`&#128565;`); return false'>&#128565;</a>
<a href='javascript:void(0)' onClick='addTextTag(`&#128566;`); return false'>&#128566;</a>
<a href='javascript:void(0)' onClick='addTextTag(`&#128567;`); return false'>&#128567;</a>
<a href='javascript:void(0)' onClick='addTextTag(`&#128568;`); return false'>&#128568;</a>
<a href='javascript:void(0)' onClick='addTextTag(`&#128569;`); return false'>&#128569;</a>
<a href='javascript:void(0)' onClick='addTextTag(`&#128570;`); return false'>&#128570;</a>
<a href='javascript:void(0)' onClick='addTextTag(`&#128571;`); return false'>&#128571;</a>
<a href='javascript:void(0)' onClick='addTextTag(`&#128572;`); return false'>&#128572;</a>
<a href='javascript:void(0)' onClick='addTextTag(`&#128573;`); return false'>&#128573;</a>
<a href='javascript:void(0)' onClick='addTextTag(`&#128574;`); return false'>&#128574;</a>
<a href='javascript:void(0)' onClick='addTextTag(`&#128575;`); return false'>&#128575;</a>
<a href='javascript:void(0)' onClick='addTextTag(`&#128576;`); return false'>&#128576;</a>
<a href='javascript:void(0)' onClick='addTextTag(`&#128577;`); return false'>&#128577;</a>
<a href='javascript:void(0)' onClick='addTextTag(`&#128578;`); return false'>&#128578;</a>
<a href='javascript:void(0)' onClick='addTextTag(`&#128579;`); return false'>&#128579;</a>
<a href='javascript:void(0)' onClick='addTextTag(`&#128580;`); return false'>&#128580;</a>
<a href='javascript:void(0)' onClick='addTextTag(`&#129296;`); return false'>&#129296;</a>
<a href='javascript:void(0)' onClick='addTextTag(`&#129297;`); return false'>&#129297;</a>
<a href='javascript:void(0)' onClick='addTextTag(`&#129298;`); return false'>&#129298;</a>
<a href='javascript:void(0)' onClick='addTextTag(`&#129299;`); return false'>&#129299;</a>
<a href='javascript:void(0)' onClick='addTextTag(`&#129300;`); return false'>&#129300;</a>
<a href='javascript:void(0)' onClick='addTextTag(`&#129301;`); return false'>&#129301;</a>
<a href='javascript:void(0)' onClick='addTextTag(`&#129312;`); return false'>&#129312;</a>
<a href='javascript:void(0)' onClick='addTextTag(`&#129313;`); return false'>&#129313;</a>
<a href='javascript:void(0)' onClick='addTextTag(`&#129314;`); return false'>&#129314;</a>
<a href='javascript:void(0)' onClick='addTextTag(`&#129315;`); return false'>&#129315;</a>
<a href='javascript:void(0)' onClick='addTextTag(`&#129316;`); return false'>&#129316;</a>
<a href='javascript:void(0)' onClick='addTextTag(`&#129317;`); return false'>&#129317;</a>
<a href='javascript:void(0)' onClick='addTextTag(`&#129318;`); return false'>&#129318;</a>
<a href='javascript:void(0)' onClick='addTextTag(`&#129319;`); return false'>&#129319;</a>
<a href='javascript:void(0)' onClick='addTextTag(`&#129320;`); return false'>&#129320;</a>
<a href='javascript:void(0)' onClick='addTextTag(`&#129321;`); return false'>&#129321;</a>
<a href='javascript:void(0)' onClick='addTextTag(`&#129322;`); return false'>&#129322;</a>
<a href='javascript:void(0)' onClick='addTextTag(`&#129323;`); return false'>&#129323;</a>
<a href='javascript:void(0)' onClick='addTextTag(`&#129324;`); return false'>&#129324;</a>
<a href='javascript:void(0)' onClick='addTextTag(`&#129325;`); return false'>&#129325;</a>
<a href='javascript:void(0)' onClick='addTextTag(`&#129326;`); return false'>&#129326;</a>
<a href='javascript:void(0)' onClick='addTextTag(`&#129327;`); return false'>&#129327;</a>
<a href='javascript:void(0)' onClick='addTextTag(`&#129488;`); return false'>&#129488;</a>
<a href='javascript:void(0)' onClick='addTextTag(`&#129311;`); return false'>&#129311;</a>
<a href='javascript:void(0)' onClick='addTextTag(`&#128077;`); return false'>&#128077;</a>
<a href='javascript:void(0)' onClick='addTextTag(`&#128078;`); return false'>&#128078;</a>
<a href='javascript:void(0)' onClick='addTextTag(`&#128075;`); return false'>&#128075;</a>
<a href='javascript:void(0)' onClick='addTextTag(`&#128150;`); return false'>&#128150;</a>
<a href='javascript:void(0)' onClick='addTextTag(`&#128156;`); return false'>&#128156;</a>
<a href='javascript:void(0)' onClick='addTextTag(`&#9995;`); return false'>&#9995;</a>
</fieldset></td></tr></table>
";

break;
case("add") :
print "
<table align='center' border='1' style='width:100%;height:auto;'><tr><th align='center'><big>ახალი თემის გახსნა</big></th></tr></table>
<form action=index.php?x=add2topic method=post>
<table align='center' border='1' style='width:100%;height:auto;'><tr><th align='center'>სათაური <font color=red>*</font></th></tr><td align='center'><input type=text name=subject maxlength=50 value=\"\" style=\"width: 100%;\"></td></tr></table><table align='center' border='1' style='width:100%;height:auto;'><tr><th align='center'>სახელი <font color=red>*</font></th><th align='center'>ელ. ფოსტა</th></tr><tr><td align='center'><input type=text maxlength=20 name=name value='".$_COOKIE["name"]."' style=\"width: 100%;\"></td><td align='center'><input type=text name=email value='".$_COOKIE["email"]."' style=\"width: 100%;\"></td></tr></table><table align='center' border='1' style='width:100%;height:auto;'><tr><td align='center'><input type=submit value=\"გამოქვეყნება\" style=\"width: 100%;\"></td></tr>
</table>
";
$data1 = file("ban/ip.txt");
$data1size = sizeof($data1);
$n = "0";
    do {
    $datatext = explode("|", $data1[$n]);
if ($n == "0") { } else { }
$disallowed = array("$datatext[0]");
$ip = $_SERVER['REMOTE_ADDR']; 

if(in_array($ip, $disallowed)) {
 header("Location: index.php?x=suspended");
 exit;
}
$n++; } while($n < $data1size);
break;
case("add2topic"):
if ($subject == "") { print "<table align='center' border='1' style='width:100%;height:auto;'><tr><th align='center'><big>შეცდომა!</big> - შეავსეთ თემის სათაური!</th></tr></table>"; if (! is_file("bottom.php")) { } else { include "bottom.php"; } exit; }
if ($name == "") { print "<table align='center' border='1' style='width:100%;height:auto;'><tr><th align='center'><big>შეცდომა!</big> - შეავსეთ სახელი!</th></tr></table>"; if (! is_file("bottom.php")) { } else { include "bottom.php"; } exit; }
setcookie ("name",$_POST["name"],strtotime( '+360 days' ) );
setcookie ("email",$_POST["email"],strtotime( '+360 days' ) );
$ss = file("topics.txt");
$s2size = sizeof($ss);
$s2size++;
$dat = date("d.m.Y");
$text1 = "$s2size|";
$text1 = stripslashes($text1);
$text1 = htmlspecialchars($text1);
$text1 = str_replace("\r\n", "<br>", $text1);

$fp=fopen("topics.txt","a");
fputs($fp,"$text1\r\n");
fclose($fp);

$text2 = "თემის არჩევის ID: $s2size|$name|$dat|$subject|$email|$ip|";
$text2 = stripslashes($text2);
$text2 = htmlspecialchars($text2);
$text2 = str_replace("\r\n", "<br>", $text2);
$fff = "topics/$s2size.txt";
$fp=fopen("$fff","a+");
fputs($fp,"$text2\r\n");
fclose($fp);
@chmod("$fff", 0777);

print "<script language=JavaScript>window.alert('ახალი თემა გაიხსნა!');</script>";


print "
<script language=\"JavaScript\">
<!-- 
if (navigator.appName == \"Netscape\") window.location.href = \"index.php\";
else if (navigator.appName == \"Microsoft Internet Explorer\") window.location.href = \"index.php\";
else window.location.href = \"index.php\";
// -->
</script>";

break;

case("add2reply"):
if ($name == "") { print "<table align='center' border='1' style='width:100%;height:auto;'><tr><th align='center'><big>შეცდომა!</big> - შეავსეთ სახელი!</th></tr></table>"; if (! is_file("bottom.php")) { } else { include "bottom.php"; } exit; }
if ($text == "") { print "<table align='center' border='1' style='width:100%;height:auto;'><tr><th align='center'><big>შეცდომა!</big> - შეავსეთ გამოხმაურება!</th></tr></table>"; if (! is_file("bottom.php")) { } else { include "bottom.php"; } exit; }
setcookie ("name",$_POST["name"],strtotime( '+360 days' ) );
setcookie ("email",$_POST["email"],strtotime( '+360 days' ) );
$ss = file("topics/$topic.txt");
$s2size = sizeof($ss);
//$s2size++;
$dat = date("d.m.Y");
$text1 = "გამოხმაურება: $s2size|$name|$dat|$text|$email|$ip|";
$text1 = stripslashes($text1);
$text1 = htmlspecialchars($text1);
$text1 = str_replace("\r\n", "<br>", $text1);
$fp=fopen("topics/$topic.txt","a");
fputs($fp,"$text1\r\n");
fclose($fp);
print "<script language=JavaScript>window.alert('პასუხი გამოქვეყნდა!');</script>";
print "
<script language=\"JavaScript\">
<!-- 
if (navigator.appName == \"Netscape\") window.location.href = \"index.php?x=read&topic=$topic\";
else if (navigator.appName == \"Microsoft Internet Explorer\") window.location.href = \"index.php?x=read&topic=$topic\";
else window.location.href = \"index.php?x=read&topic=$topic\";
// -->
</script>";
break;

case("suspended"):

print '<table align="center" border="1" style="width:100%;height:auto;"><tr><th align="center"><big>ბანი!</big> - თქვენ შეგიჩერდათ ფორუმით სარგებლობის უფლება!</th></tr></table>';

break;
endswitch;


if (! is_file("bottom.php")) { } else { include "bottom.php"; }
?>

