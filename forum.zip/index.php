<?
if (! is_file("head.php")) { } else { include "head.php"; }
error_reporting(0);
$x = $_GET["x"];
$part = $_GET["part"];
$topic = $_GET["topic"];
$name = $_POST["name"];
$subject = $_POST["subject"];
$email = $_POST["email"];
$text = $_POST["text"];
include "config.php";

print "<table width=$width cellpadding=0 cellspacing=0 border=0 align=center>
<tr><td width=20><tr><td bgcolor=$c01>&nbsp;<img src=img/new.png align=center>&nbsp;<b><a href='index.php?x=add'>ახალი თემის გახსნა</a></b></td></tr>
<tr><td colspan=3 height=5></td></tr>
<tr><td colspan=3 bgcolor=$co3>$title</td></tr>
<tr><td colspan=3 height=5></td></tr>
</table>
";

switch($x) :
default :
print "<table width=$width cellpadding=0 cellspacing=0 border=0 align=center>";

$data1 = file("topics.txt");
$data1size = sizeof($data1);

if ($part == "") {
$n = "$data1size";
                 } else {
                         $part2 = $part*10;
                         $n = $data1size-$part2;
                        }
$g = "0";
$limx=0;
    do {
    $limx++;
      $n2 = $n+1;

    $textdata = explode("|", $data1[$n]);
    $textfile = "topics/$n2.txt";
      if (! is_file("$textfile")) { } else {
      $xx = "0";
      $data2 = file("$textfile");
      $data2size = sizeof($data2);
      if ($data2size < 2) { $icon = "img/topic0.gif"; } else { $icon = "img/topic.png"; }
  $textdata[3] = substr($textdata[3],0,200);
  $textdata[1] = substr($textdata[1],0,50);



      do {
      $textdata2 = explode("|", $data2[$xx]);
      if ($textdata2[1] != "") {

  $textdata2[3] = substr($textdata2[3],0,200);
  $textdata2[1] = substr($textdata2[1],0,50);
    if ($textdata[1] != "") {
  print "  <tr><td bgcolor=$c01><img src=$icon width=20 height=20 align=left> <a href='index.php?x=read&topic=$n2'>$textdata2[3]</a></td> <td bgcolor=$c01 width=120><b>"; if ($textdata2[4] != "") { print "<a href='mailto:$textdata2[4]'>"; } print "$textdata2[1]</a></b></td> <td bgcolor=$c01 width=80>$textdata2[2]</td></tr><tr><td height=1 background=img/pset.gif colspan=3><img src=img/pset.gif width=1 height=1></td></tr>\r\n";
                          } 

                               }
      
      if ($xx > $limit) { $xx = "$data2size"; }
      if ($limx > 10) { $n = "0"; }
      } while($xx < $data2size);
      } 

    $n--;
    } while($n+1 > 0);
 
print " <tr><td bgcolor=$c01></td><td bgcolor=$c01> (თემები: $data1size)</td><td bgcolor=$c01> </td></tr></table>

";

break;
case("read") :
if ($topic == "") { print "შეცდომა, თემა არაა არჩეული"; exit; }
$data1 = file("topics/$topic.txt");
$data1size = sizeof($data1);
   
if ($part == "") {
$n = "$data1size";
                 } else {
                         $part2 = $part*10;
                         $n = $data1size-$part2;
                        }

$limx=0;
    do {
    $limx++;

    $datatext = explode("|", $data1[$n]);
if ($n == "0") { $col = $c01; $subject = ""; } else { $col = $c01; }
if ($datatext[3] != "") {
print "<table width=$width bgcolor=$col align=center><tr><td width=*>
<font size=3><b></font></b></td><td width=150 valign=top align=right>";  if ($datatext[4] != "") { print "<a href='mailto:$datatext[4]'>"; } print "$datatext[1]</a> ($datatext[2])</td></tr>
<tr><td colspan=2>$datatext[3]
</td></tr></table><br><br>";
      } 
      $n--;
      if ($limx > 10) { $n = "0"; }
      } while($n);
      
print "
<center><h2>გამოხმაურება</h2></center>
<form action=index.php?x=add2reply&topic=$topic method=post>
<table width=$width align=center>
<tr><td colspan=2><input type=hidden name=subject value=\"\"></td></tr>
<tr><td width=50%>სახელი:&nbsp;<br><input type=text name=name maxlength=20 style=\"width: 100%;\"></td><td width=50%>ელ. ფოსტა:&nbsp;<br><input type=text name=email style=\"width: 100%;\"></td></tr>
<tr><td colspan=2>გამოხმაურება:&nbsp;<br><textarea rows=7 name=text style=\"width: 100%;\"></textarea></td></tr>
<tr><td colspan=2><br><input type=submit value=\"გამოქვეყნება\" style=\"width: 100%;\"></td></tr>
</table>
";
break;
case("add") :
print "
<center><h2>ახალი თემის გახსნა</h2></center>
<form action=index.php?x=add2topic method=post>
<table width=$width align=center>
<tr><td colspan=2>სათაური:&nbsp;<br><input type=text name=subject maxlength=50 value=\"\" style=\"width: 100%;\"></td></tr>
<tr><td width=50%>სახელი:&nbsp;<br><input type=text maxlength=20 name=name style=\"width: 100%;\"></td><td width=50%>ელ. ფოსტა:&nbsp;<br><input type=text name=email style=\"width: 100%;\"></td></tr>
<tr><td colspan=2><br><input type=submit value=\"გამოქვეყნება\" style=\"width: 100%;\"></td></tr>
</table>
";
break;
case("add2topic"):
if ($subject == "") { print "<h2>შეცდომა!</h2> - შეავსეთ თემის სათაური!<br><br>"; if (! is_file("bottom.php")) { } else { include "bottom.php"; } exit; }
if ($name == "") { print "<h2>შეცდომა!</h2> - შეავსეთ სახელი!<br><br>"; if (! is_file("bottom.php")) { } else { include "bottom.php"; } exit; }
$ss = file("topics.txt");
$s2size = sizeof($ss);
$s2size++;
$dat = date("d.m.Y");
$text1 = "$s2size|";
$text1 = stripslashes($text1);
$text1 = htmlspecialchars($text1);
$text1 = str_replace("\r\n", "<br>", $text1);

$fp=fopen("topics.txt","a");
fputs($fp,"$text1\r\n");
fclose($fp);

$text2 = "თემის არჩევის ID: $s2size|$name|$dat|$subject|$email|";
$text2 = stripslashes($text2);
$text2 = htmlspecialchars($text2);
$text2 = str_replace("\r\n", "<br>", $text2);
$fff = "topics/$s2size.txt";
$fp=fopen("$fff","a+");
fputs($fp,"$text2\r\n");
fclose($fp);
@chmod("$fff", 0777);

print "<script language=JavaScript>window.alert('ახალი თემა გაიხსნა!');</script>";


print "
<script language=\"JavaScript\">
<!-- 
if (navigator.appName == \"Netscape\") window.location.href = \"index.php\";
else if (navigator.appName == \"Microsoft Internet Explorer\") window.location.href = \"index.php\";
else window.location.href = \"index.php\";
// -->
</script>";

break;

case("add2reply"):
if ($name == "") { print "<h2>შეცდომა!</h2> - შეავსეთ სახელი!<br><br>"; if (! is_file("bottom.php")) { } else { include "bottom.php"; } exit; }
if ($text == "") { print "<h2>შეცდომა!</h2> - შეავსეთ პასუხი!<br><br>"; if (! is_file("bottom.php")) { } else { include "bottom.php"; } exit; }
$ss = file("topics/$topic.txt");
$s2size = sizeof($ss);
//$s2size++;
$dat = date("d.m.Y");
$text1 = "გამოხმაურება: $s2size|$name|$dat|$text|$email|";
$text1 = stripslashes($text1);
$text1 = htmlspecialchars($text1);
$text1 = str_replace("\r\n", "<br>", $text1);
$fp=fopen("topics/$topic.txt","a");
fputs($fp,"$text1\r\n");
fclose($fp);
print "<script language=JavaScript>window.alert('პასუხი გამოქვეყნდა!');</script>";
print "
<script language=\"JavaScript\">
<!-- 
if (navigator.appName == \"Netscape\") window.location.href = \"index.php?x=read&topic=$topic\";
else if (navigator.appName == \"Microsoft Internet Explorer\") window.location.href = \"index.php?x=read&topic=$topic\";
else window.location.href = \"index.php?x=read&topic=$topic\";
// -->
</script>";
break;
endswitch;
print " <br>
<table cellpadding=0 cellspacing=0 width=$width align=center>
<tr>
 <td>";





$num4 = $data1size/10;
$num4 = explode(".", $num4);
$n = "0";

do {
$nn = $n+1;
print " [<a href='index.php?part=$n&x=$x&topic=$topic'>$nn</a>] ";
$n++;
 } while($n < $num4[0]+1);

 print "</td>
</tr>
</table><br>";

if (! is_file("bottom.php")) { } else { include "bottom.php"; }
?>

