<?php
if (! is_file("head.php")) { } else { include "head.php"; }
include 'config.php';

echo '<table width=$width cellpadding=0 cellspacing=0 border=0 align=center>';
?>
<?

$topic = $_POST['topic'];
@unlink("topics/$topic.txt");

function replace($line,$file){if(file_get_contents($file)==$line){file_put_contents($file,'');}else if(file($file)[0]==$line.PHP_EOL){file_put_contents($file,str_replace($line.PHP_EOL,'', file_get_contents($file)));}else{file_put_contents($file,str_replace(PHP_EOL.$line,'',file_get_contents($file)));}}
replace("$topic|", "topics.txt");

?>
<?

$ip = $_POST['ip'];

if (isset($_GET['ipsoft']))
  { 
error_reporting(0);
$ban = file("ban/ip.txt");
$text1 = "$ip|";
$text1 = stripslashes($text1);
$text1 = htmlspecialchars($text1);
$fp=fopen("ban/ip.txt","a");
fputs($fp,"$text1\r\n");
fclose($fp);
}
?>
<?
if (isset($_GET['clear']))
  {

@unlink("ban/ip.txt");

}
?>
<?php
$user = $_POST['user'];
$pass = $_POST['pass'];

if($user == "admin"
&& $pass == "12345678")
{
print "<center><h2>თემის წაშლა</h2></center>
<form method=POST><table align=center><tr><center>თემის არჩევის ID:</center></tr><tr><td><center><input type=number name=topic required></center><tr><th><button>წაშლა</button></th></tr></td></tr></table></form><br><br>";

print "<center><h2>მომხმარებლის დაბლოკვა</h2></center>
<form method=POST action=admin.php?ipsoft><table align=center><tr><center>მომხმარებლის IP მისამართი:</center></tr><tr><td><center><input type=text name=ip required></center><tr><th><button>ბანი</button></th></tr></td></tr></table></form><br><br>";
print "<form method=POST action=admin.php?clear><table align=center><tr><th><button>შავი სიის წაშლა</button></th></tr></table></form><br><br>";
}
else
{
    if(isset($_POST))
    {?>
<center><h2>ავტორიზაცია</h2></center>
            <form method="POST" action="admin.php">
                         <table>ადმინისტრატორი:<br> <input type="text" name="user"></input>
            <br>პაროლი:<br> <input type="password" name="pass"></input><br/>
            <tr><th><input type="submit" name="submit" value="შესვლა"></input></tr></th></table>
            </form>
			</center><br><br>
    <?}
}
?>
</table>
<?php
if (! is_file("bottom.php")) { } else { include "bottom.php"; }
?>
